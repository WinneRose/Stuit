﻿namespace STUIT
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.hour_bar = new Bunifu.UI.Winforms.BunifuProgressBar();
            this.min_bar = new Bunifu.UI.Winforms.BunifuProgressBar();
            this.sn_bar = new Bunifu.UI.Winforms.BunifuProgressBar();
            this.mola_btn = new MetroFramework.Controls.MetroButton();
            this.bunifuShadowPanel2 = new Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.c_sure = new MetroFramework.Controls.MetroLabel();
            this.start_btn = new MetroFramework.Controls.MetroButton();
            this.m_amount = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.dinlenme = new MetroFramework.Controls.MetroTabPage();
            this.mola_List = new System.Windows.Forms.ListBox();
            this.ders = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.ders_list = new System.Windows.Forms.ListBox();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.hedef_saat = new MetroFramework.Controls.MetroTextBox();
            this.hedef_dakika = new MetroFramework.Controls.MetroTextBox();
            this.not = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.h_kaydet = new MetroFramework.Controls.MetroButton();
            this.bunifuShadowPanel1.SuspendLayout();
            this.dinlenme.SuspendLayout();
            this.ders.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuShadowPanel1.Controls.Add(this.h_kaydet);
            this.bunifuShadowPanel1.Controls.Add(this.metroLabel8);
            this.bunifuShadowPanel1.Controls.Add(this.hedef_dakika);
            this.bunifuShadowPanel1.Controls.Add(this.metroLabel5);
            this.bunifuShadowPanel1.Controls.Add(this.hedef_saat);
            this.bunifuShadowPanel1.Controls.Add(this.metroLabel7);
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(0, 4);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.Empty;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(167, 547);
            this.bunifuShadowPanel1.TabIndex = 0;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(210, 60);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(34, 19);
            this.metroLabel1.TabIndex = 12;
            this.metroLabel1.Text = "Saat";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(197, 98);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(47, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Dakika";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(197, 137);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(46, 19);
            this.metroLabel3.TabIndex = 17;
            this.metroLabel3.Text = "Saniye";
            // 
            // hour_bar
            // 
            this.hour_bar.Animation = 0;
            this.hour_bar.AnimationStep = 10;
            this.hour_bar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hour_bar.BackgroundImage")));
            this.hour_bar.BorderColor = System.Drawing.Color.Black;
            this.hour_bar.BorderRadius = 5;
            this.hour_bar.BorderThickness = 2;
            this.hour_bar.Location = new System.Drawing.Point(250, 60);
            this.hour_bar.MaximumValue = 24;
            this.hour_bar.MinimumValue = 0;
            this.hour_bar.Name = "hour_bar";
            this.hour_bar.ProgressBackColor = System.Drawing.Color.White;
            this.hour_bar.ProgressColorLeft = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.hour_bar.ProgressColorRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.hour_bar.Size = new System.Drawing.Size(284, 23);
            this.hour_bar.TabIndex = 18;
            this.hour_bar.Value = 0;
            // 
            // min_bar
            // 
            this.min_bar.Animation = 0;
            this.min_bar.AnimationStep = 10;
            this.min_bar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("min_bar.BackgroundImage")));
            this.min_bar.BorderColor = System.Drawing.Color.Black;
            this.min_bar.BorderRadius = 5;
            this.min_bar.BorderThickness = 2;
            this.min_bar.Location = new System.Drawing.Point(250, 98);
            this.min_bar.MaximumValue = 100;
            this.min_bar.MinimumValue = 0;
            this.min_bar.Name = "min_bar";
            this.min_bar.ProgressBackColor = System.Drawing.Color.White;
            this.min_bar.ProgressColorLeft = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.min_bar.ProgressColorRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.min_bar.Size = new System.Drawing.Size(284, 23);
            this.min_bar.TabIndex = 19;
            this.min_bar.Value = 0;
            // 
            // sn_bar
            // 
            this.sn_bar.Animation = 0;
            this.sn_bar.AnimationStep = 10;
            this.sn_bar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sn_bar.BackgroundImage")));
            this.sn_bar.BorderColor = System.Drawing.Color.Black;
            this.sn_bar.BorderRadius = 5;
            this.sn_bar.BorderThickness = 2;
            this.sn_bar.Location = new System.Drawing.Point(250, 133);
            this.sn_bar.MaximumValue = 60;
            this.sn_bar.MinimumValue = 0;
            this.sn_bar.Name = "sn_bar";
            this.sn_bar.ProgressBackColor = System.Drawing.Color.White;
            this.sn_bar.ProgressColorLeft = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sn_bar.ProgressColorRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.sn_bar.Size = new System.Drawing.Size(284, 23);
            this.sn_bar.TabIndex = 20;
            this.sn_bar.Value = 0;
            // 
            // mola_btn
            // 
            this.mola_btn.Location = new System.Drawing.Point(363, 183);
            this.mola_btn.Name = "mola_btn";
            this.mola_btn.Size = new System.Drawing.Size(104, 23);
            this.mola_btn.TabIndex = 21;
            this.mola_btn.Text = "Mola";
            this.mola_btn.Click += new System.EventHandler(this.mola_btn_Click);
            // 
            // bunifuShadowPanel2
            // 
            this.bunifuShadowPanel2.BorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuShadowPanel2.Location = new System.Drawing.Point(160, 245);
            this.bunifuShadowPanel2.Name = "bunifuShadowPanel2";
            this.bunifuShadowPanel2.PanelColor = System.Drawing.Color.Empty;
            this.bunifuShadowPanel2.ShadowDept = 2;
            this.bunifuShadowPanel2.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel2.Size = new System.Drawing.Size(811, 13);
            this.bunifuShadowPanel2.TabIndex = 18;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(632, 60);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(86, 19);
            this.metroLabel4.TabIndex = 22;
            this.metroLabel4.Text = "Çalışılan Süre";
            // 
            // c_sure
            // 
            this.c_sure.AutoSize = true;
            this.c_sure.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.c_sure.Location = new System.Drawing.Point(641, 79);
            this.c_sure.Name = "c_sure";
            this.c_sure.Size = new System.Drawing.Size(67, 25);
            this.c_sure.TabIndex = 23;
            this.c_sure.Text = "0 : 0 : 0";
            // 
            // start_btn
            // 
            this.start_btn.Location = new System.Drawing.Point(250, 183);
            this.start_btn.Name = "start_btn";
            this.start_btn.Size = new System.Drawing.Size(95, 23);
            this.start_btn.TabIndex = 24;
            this.start_btn.Text = "Başlat";
            this.start_btn.Click += new System.EventHandler(this.start_btn_Click);
            // 
            // m_amount
            // 
            this.m_amount.AutoSize = true;
            this.m_amount.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.m_amount.Location = new System.Drawing.Point(813, 79);
            this.m_amount.Name = "m_amount";
            this.m_amount.Size = new System.Drawing.Size(21, 25);
            this.m_amount.TabIndex = 26;
            this.m_amount.Text = "0";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(790, 60);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(74, 19);
            this.metroLabel6.TabIndex = 25;
            this.metroLabel6.Text = "Mola Sayısı";
            // 
            // dinlenme
            // 
            this.dinlenme.Controls.Add(this.mola_List);
            this.dinlenme.HorizontalScrollbarBarColor = true;
            this.dinlenme.HorizontalScrollbarSize = 1;
            this.dinlenme.Location = new System.Drawing.Point(4, 35);
            this.dinlenme.Name = "dinlenme";
            this.dinlenme.Size = new System.Drawing.Size(713, 240);
            this.dinlenme.Style = MetroFramework.MetroColorStyle.Orange;
            this.dinlenme.TabIndex = 1;
            this.dinlenme.Text = "Mola";
            this.dinlenme.VerticalScrollbarBarColor = true;
            // 
            // mola_List
            // 
            this.mola_List.FormattingEnabled = true;
            this.mola_List.Location = new System.Drawing.Point(0, 3);
            this.mola_List.Name = "mola_List";
            this.mola_List.Size = new System.Drawing.Size(713, 225);
            this.mola_List.TabIndex = 29;
            // 
            // ders
            // 
            this.ders.Controls.Add(this.ders_list);
            this.ders.HorizontalScrollbarBarColor = true;
            this.ders.Location = new System.Drawing.Point(4, 35);
            this.ders.Name = "ders";
            this.ders.Size = new System.Drawing.Size(713, 240);
            this.ders.Style = MetroFramework.MetroColorStyle.Orange;
            this.ders.TabIndex = 0;
            this.ders.Text = "Ders";
            this.ders.VerticalScrollbarBarColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(0, 516);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(129, 19);
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "STUIT by WinneRose";
            // 
            // ders_list
            // 
            this.ders_list.FormattingEnabled = true;
            this.ders_list.Location = new System.Drawing.Point(3, 3);
            this.ders_list.Name = "ders_list";
            this.ders_list.Size = new System.Drawing.Size(699, 212);
            this.ders_list.TabIndex = 2;
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.ders);
            this.metroTabControl1.Controls.Add(this.dinlenme);
            this.metroTabControl1.FontSize = MetroFramework.MetroTabControlSize.Tall;
            this.metroTabControl1.Location = new System.Drawing.Point(173, 264);
            this.metroTabControl1.Multiline = true;
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(721, 279);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTabControl1.TabIndex = 28;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(23, 47);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(126, 19);
            this.metroLabel7.TabIndex = 0;
            this.metroLabel7.Text = "Hedef Çalışma Saati";
            // 
            // hedef_saat
            // 
            this.hedef_saat.Location = new System.Drawing.Point(24, 76);
            this.hedef_saat.Name = "hedef_saat";
            this.hedef_saat.PromptText = "Saat";
            this.hedef_saat.Size = new System.Drawing.Size(125, 23);
            this.hedef_saat.TabIndex = 1;
            // 
            // hedef_dakika
            // 
            this.hedef_dakika.Location = new System.Drawing.Point(24, 118);
            this.hedef_dakika.Name = "hedef_dakika";
            this.hedef_dakika.PromptText = "Dakika";
            this.hedef_dakika.Size = new System.Drawing.Size(125, 23);
            this.hedef_dakika.TabIndex = 2;
            // 
            // not
            // 
            this.not.AutoSize = true;
            this.not.Location = new System.Drawing.Point(657, 122);
            this.not.Name = "not";
            this.not.Size = new System.Drawing.Size(83, 19);
            this.not.TabIndex = 3;
            this.not.Text = "metroLabel8";
            this.not.Visible = false;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(24, 153);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(0, 0);
            this.metroLabel8.TabIndex = 4;
            // 
            // h_kaydet
            // 
            this.h_kaydet.Location = new System.Drawing.Point(37, 153);
            this.h_kaydet.Name = "h_kaydet";
            this.h_kaydet.Size = new System.Drawing.Size(75, 23);
            this.h_kaydet.TabIndex = 5;
            this.h_kaydet.Text = "Kaydet";
            this.h_kaydet.Click += new System.EventHandler(this.h_kaydet_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 544);
            this.Controls.Add(this.not);
            this.Controls.Add(this.metroTabControl1);
            this.Controls.Add(this.m_amount);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.start_btn);
            this.Controls.Add(this.c_sure);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.mola_btn);
            this.Controls.Add(this.sn_bar);
            this.Controls.Add(this.min_bar);
            this.Controls.Add(this.hour_bar);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.Controls.Add(this.bunifuShadowPanel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.dinlenme.ResumeLayout(false);
            this.ders.ResumeLayout(false);
            this.metroTabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel bunifuShadowPanel1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private Bunifu.UI.Winforms.BunifuProgressBar min_bar;
        private Bunifu.UI.Winforms.BunifuProgressBar sn_bar;
        private Bunifu.UI.Winforms.BunifuProgressBar hour_bar;
        private MetroFramework.Controls.MetroButton mola_btn;
        private Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel bunifuShadowPanel2;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel c_sure;
        private MetroFramework.Controls.MetroButton start_btn;
        private System.Windows.Forms.Timer timer1;
        private MetroFramework.Controls.MetroLabel m_amount;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTabPage dinlenme;
        private System.Windows.Forms.ListBox mola_List;
        private MetroFramework.Controls.MetroTabPage ders;
        private System.Windows.Forms.ListBox ders_list;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private System.Windows.Forms.Timer timer2;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox hedef_dakika;
        private MetroFramework.Controls.MetroTextBox hedef_saat;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel not;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroButton h_kaydet;
    }
}

