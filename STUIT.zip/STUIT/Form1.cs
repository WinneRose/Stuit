﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace STUIT
{
    public partial class Form1 : MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }



        int saat = 0, dakika = 0, saniye = 0, mola = 0,ders_amount =0;


        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void h_kaydet_Click(object sender, EventArgs e)
        {
            int h_saat = Convert.ToInt32(hedef_saat.Text);
            int h_dakika = Convert.ToInt32(hedef_dakika.Text);


            if (saat == h_saat && dakika == h_dakika)
            {

                not.Text = ("Tebrikler Hedefinize Ulaştınız");
                not.Visible = true;


            }
        }

        private void mola_btn_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Start();
            
            mola++;

            m_amount.Text = mola.ToString();

            ders_list.Items.Add("Çalışılan Süre:  " + saat + " : " + dakika + " : " + saniye + "  Mola Sayısı:  " + mola);



        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            

            timer1.Start();
            mola_List.Items.Add("Mola Verilen Süre:  "  + saat + " : " + dakika + " : " + saniye  );
            timer2.Stop();
            ders_amount++;


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            saniye++;
            sn_bar.Value = saniye;

            if (saniye == 60)
            {
                dakika++;
                min_bar.Value = dakika;

                saniye = 0;
            }
            if (dakika == 60)
            {
                saat++;
                hour_bar.Value = saat;
                dakika = 0;
            }

            c_sure.Text = saat + " : " + dakika + " : " + saniye;

            
            


        }

        

        private void timer2_Tick(object sender, EventArgs e)
        {
            saniye++;
            sn_bar.Value = saniye;

            if (saniye == 60)
            {
                dakika++;
                min_bar.Value = dakika;

                saniye = 0;
            }
            if (dakika == 60)
            {
                saat++;
                hour_bar.Value = saat;
                dakika = 0;
            }
            
        }


    }
}
